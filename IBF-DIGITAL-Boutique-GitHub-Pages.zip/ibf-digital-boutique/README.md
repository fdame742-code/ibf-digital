# IBF.DIGITAL — Boutique GitHub Pages

Site statique responsive avec les pages Accueil, Boutique, Réservations, Vidéos et Contact.

## Publication sur GitHub Pages
1. Décompressez le ZIP.
2. Déposez tous les fichiers dans la racine de votre dépôt GitHub.
3. Ouvrez **Settings → Pages**.
4. Choisissez **Deploy from a branch**, branche `main`, dossier `/ (root)`, puis **Save**.
5. Patientez quelques minutes et ouvrez l'URL fournie par GitHub Pages.

## Personnalisation
- Produits, descriptions et prix d'exemple : modifiez le tableau `PRODUCTS` dans `script.js`.
- Adresse de contact : remplacez `contact@ibf.digital` dans `script.js` et `contact.html`.
- Logos : les quatre propositions Webador sont référencées dans `script.js`. Pour une meilleure pérennité, téléchargez vos logos autorisés dans un dossier `assets/` et remplacez les URL distantes.
- Couleurs : modifiez les variables CSS au début de `styles.css`.

## Important : ce qui est / n'est pas activé
- Fonctionnel côté navigateur : navigation, sélection de logo, filtres, panier et quantités, stockage du panier sur l'appareil, formulaires qui préparent un e-mail.
- **Le paiement réel n'est pas activé** : le bouton de paiement est une démonstration. Pour encaisser, reliez un prestataire tel que Stripe Checkout ou PayPal via des liens de paiement ou un backend sécurisé.
- **La réservation n'est pas automatique** : le formulaire prépare un e-mail. Pour calendrier, disponibilité, confirmation et rappels, connectez un service de réservation.
- **La livraison vidéo payante n'est pas sécurisée** : ne mettez pas des vidéos payantes directement dans des liens publics. Utilisez une plateforme vidéo/formation ou un backend qui contrôle l'accès après paiement.
- Avant la mise en vente, ajoutez les mentions légales, politique de confidentialité, conditions générales de vente, politique de remboursement et informations de contact adaptées à votre activité.
