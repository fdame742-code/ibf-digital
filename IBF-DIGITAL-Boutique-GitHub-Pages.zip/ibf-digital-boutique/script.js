const LOGOS = [
  "https://primary.jwwb.nl/public/m/c/l/temp-njdodrviqsafhewzrlvy/ai-logo-5dcc0aacbd81-standard.png",
  "https://primary.jwwb.nl/public/m/c/l/temp-njdodrviqsafhewzrlvy/ai-logo-b416eae07c3f-standard.png",
  "https://primary.jwwb.nl/public/m/c/l/temp-njdodrviqsafhewzrlvy/ai-logo-113f6ee2c1ca-standard.png",
  "https://primary.jwwb.nl/public/m/c/l/temp-njdodrviqsafhewzrlvy/ai-logo-9bcede6533b6-standard.png"
];
const PRODUCTS = [
 {id:"audit",name:"Audit de présence digitale",type:"service",category:"Services",price:89,icon:"🔎",desc:"Un diagnostic clair de vos réseaux sociaux, contenus et pistes d'amélioration.",tag:"Conseillé"},
 {id:"booking-strategy",name:"Rendez-vous stratégie digitale",type:"booking",category:"Réservation",price:45,icon:"🗓️",desc:"Une session individuelle de 45 minutes pour clarifier votre projet.",tag:"45 min"},
 {id:"video-brand",name:"Pack vidéos courtes",type:"video",category:"Vidéos",price:29,icon:"🎬",desc:"Une collection de modèles et conseils pour créer des vidéos courtes.",tag:"Digital"},
 {id:"social-kit",name:"Kit de contenus réseaux sociaux",type:"digital",category:"Produits digitaux",price:19,icon:"✨",desc:"Un kit pratique pour organiser vos publications et gagner du temps.",tag:"Téléchargement"},
 {id:"booking-consult",name:"Consultation création de contenu",type:"booking",category:"Réservation",price:60,icon:"💬",desc:"Un échange de 60 minutes autour de vos idées, formats et messages.",tag:"60 min"},
 {id:"video-masterclass",name:"Masterclass vidéo marketing",type:"video",category:"Vidéos",price:39,icon:"▶️",desc:"Une formation vidéo pour structurer une vidéo qui capte l'attention.",tag:"Formation"}
];
const money = n => new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR"}).format(n);
function getCart(){try{return JSON.parse(localStorage.getItem("ibf_cart")||"[]")}catch{return []}}
function saveCart(c){localStorage.setItem("ibf_cart",JSON.stringify(c));updateCartCount()}
function addToCart(id){let c=getCart();let item=c.find(x=>x.id===id);if(item)item.qty++;else c.push({id,qty:1});saveCart(c);showToast("Ajouté au panier");renderCart()}
function updateCartCount(){let count=getCart().reduce((s,x)=>s+x.qty,0);document.querySelectorAll("[data-cart-count]").forEach(el=>el.textContent=count)}
function renderCart(){
 const target=document.querySelector("#cart-items");if(!target)return;
 const cart=getCart();let total=0;
 if(!cart.length){target.innerHTML='<div class="empty">Votre panier est vide.<br>Ajoutez un service ou une vidéo pour commencer.</div>'}
 else target.innerHTML=cart.map(line=>{const p=PRODUCTS.find(x=>x.id===line.id);if(!p)return "";total+=p.price*line.qty;return `<div class="cart-line"><div><b>${p.name}</b><small>${money(p.price)} l’unité</small><div class="qty"><button onclick="changeQty('${p.id}',-1)" aria-label="Retirer une unité">−</button><span>${line.qty}</span><button onclick="changeQty('${p.id}',1)" aria-label="Ajouter une unité">+</button></div></div><b>${money(p.price*line.qty)}</b></div>`}).join("");
 const t=document.querySelector("#cart-total");if(t)t.textContent=money(total);
}
function changeQty(id,delta){let c=getCart();let x=c.find(y=>y.id===id);if(x)x.qty+=delta;c=c.filter(y=>y.qty>0);saveCart(c);renderCart()}
function openCart(){document.querySelector("#cart-drawer")?.classList.add("open");renderCart()}
function closeCart(){document.querySelector("#cart-drawer")?.classList.remove("open")}
function showToast(s){let t=document.querySelector("#toast");if(!t)return;t.textContent=s;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function productCard(p){return `<article class="card"><div class="card-top"><div class="product-icon">${p.icon}</div></div><div class="card-content"><span class="pill">${p.tag}</span><h3>${p.name}</h3><p>${p.desc}</p><div class="meta"><span class="price">${money(p.price)}</span><span style="color:#647084;font-size:.8rem">${p.category}</span></div><div class="card-actions"><button class="button small" onclick="addToCart('${p.id}')">Ajouter au panier</button>${p.type==="booking"?`<a class="button secondary small" href="booking.html">Réserver</a>`:""}</div></div></article>`}
function initProducts(){document.querySelectorAll("[data-product-list]").forEach(el=>{let mode=el.dataset.productList;let list=PRODUCTS;if(mode==="featured")list=PRODUCTS.slice(0,3);if(mode==="videos")list=PRODUCTS.filter(p=>p.type==="video");if(mode==="bookings")list=PRODUCTS.filter(p=>p.type==="booking");el.innerHTML=list.map(productCard).join("")});document.querySelectorAll("[data-filter]").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll("[data-filter]").forEach(b=>b.classList.remove("active"));btn.classList.add("active");const f=btn.dataset.filter;const el=document.querySelector("[data-product-list='all']");if(el)el.innerHTML=PRODUCTS.filter(p=>f==="all"||p.type===f||p.category===f).map(productCard).join("")}))}
function initCommon(){
 document.querySelectorAll("[data-cart-open]").forEach(b=>b.addEventListener("click",openCart));
 document.querySelectorAll("[data-cart-close]").forEach(b=>b.addEventListener("click",closeCart));
 document.querySelectorAll("[data-menu-toggle]").forEach(b=>b.addEventListener("click",()=>document.querySelector(".navlinks")?.classList.toggle("open")));
 document.querySelectorAll("[data-year]").forEach(el=>el.textContent=new Date().getFullYear());
 document.querySelectorAll("[data-logo-choice]").forEach((el,i)=>{el.src=LOGOS[i];el.onerror=()=>{el.style.display="none"}});
 updateCartCount();renderCart();
 document.querySelectorAll("[data-checkout]").forEach(b=>b.addEventListener("click",()=>{showToast("Démo : configurez un lien de paiement sécurisé avant la mise en vente.");}));
 document.querySelectorAll("form[data-booking-form]").forEach(form=>form.addEventListener("submit",e=>{e.preventDefault();const d=new FormData(form);const subject=encodeURIComponent("Demande de réservation - IBF.DIGITAL");const body=encodeURIComponent(`Bonjour,\n\nJe souhaite réserver une session.\nNom : ${d.get("name")}\nEmail : ${d.get("email")}\nService : ${d.get("service")}\nDate souhaitée : ${d.get("date")}\nMessage : ${d.get("message")||"Aucun"}\n\nMerci.`);window.location.href=`mailto:contact@ibf.digital?subject=${subject}&body=${body}`;}));
}
document.addEventListener("DOMContentLoaded",()=>{initCommon();initProducts()});
